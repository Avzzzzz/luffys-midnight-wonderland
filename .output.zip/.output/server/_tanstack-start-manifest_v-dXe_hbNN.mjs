//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-dXe_hbNN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/avant/Desktop/luffy bday/luffys-midnight-wonderland/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BInD0x7V.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BInD0x7V.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/avant/Desktop/luffy bday/luffys-midnight-wonderland/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BVFVx8GB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
