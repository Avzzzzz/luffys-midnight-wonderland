import { n as __toESM } from "../_runtime.mjs";
import { i as AnimatePresence, n as useMotionValue, r as motion, t as useSpring } from "../_libs/framer-motion+[...].mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as Mic, i as RotateCcw, n as Volume2, o as Camera, r as Sparkles, t as VolumeX } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BXhGONdn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var content = {
	intro: {
		greeting: "Hey, Luffy! 🌙",
		line: "I made a little universe for someone special.",
		button: "Enter your little universe ♡"
	},
	keys: {
		heading: "Before you enter, you have three little things to discover...",
		hint: "tap a key to unlock it",
		labels: [
			"Moon key",
			"Heart key",
			"Cat key"
		],
		continue: "Keep going ♡"
	},
	cards: [
		{
			title: "How this little story started",
			body: ["Who would've thought that a random game of Valorant would lead me to someone so special?", "I met you as Luffy, just another person I happened to encounter online. Little did I know that behind that username was someone who would eventually become such an important part of my life."]
		},
		{
			title: "The unexpected plot twist",
			body: [
				"Honestly, you weren't initially the type of person I thought I was looking for. I even rejected you at first.",
				"But somewhere along the way, I started seeing you differently. I realised that what I was searching for wasn't necessarily a particular type of person. It was someone who made me feel loved, understood and happy.",
				"And somehow, that person turned out to be you."
			]
		},
		{
			title: "Our little anime corner",
			shows: [{
				title: "The Fragrant Flower Blooms with Dignity",
				image: "/images/the-fragrant-flower-blooms-with-dignity-anime-review-3843575.webp"
			}, {
				title: "Waguri & Rintaro",
				image: "/images/waguri-rintaro.jpg"
			}],
			body: ["Some stories are beautiful to watch, but they're even more special when you have someone to watch them with."]
		}
	],
	stars: {
		heading: "A little collection of things I love about you",
		hint: "tap the stars ✦",
		messages: [
			"Your genuinely good heart.",
			"The way you believed in love.",
			"Your kindness, even in little things.",
			"Your gaming obsession.",
			"The way you talk",
			"Your moon-loving soul.",
			"The way you make me smile.",
			"Simply being you."
		],
		continue: "Next little page ♡"
	},
	memory: {
		heading: "Our little almost-real-life memory",
		caption: "Not the usual couple picture, but it's ours.",
		hope: "One day, I hope we get to take a picture where we don't have to hide behind a phone.",
		placeholder: "our hidden-face picture goes here",
		continue: "One more thing..."
	},
	confession: {
		envelope: "Something I don't always admit...",
		body: [
			"Okay, I get jealous sometimes. Especially when you talk to other girls. Maybe it's because I care about you more than I sometimes know how to explain.",
			"I know we're both our own people, but I hope you always understand how special you are to me.",
			"I don't want to be just another person in your server. I want to be someone who has a special place in your heart."
		],
		continue: "Now close your eyes... ✦"
	},
	cake: {
		title: "HAPPY BIRTHDAY, MY LUFFY! ♡",
		line: "Another year of you being you. And I'm really happy I get to be part of your story.",
		instruction: "Make a wish and blow out your candles!",
		mic: "or blow into your mic 🎤",
		done: "Your wish is on its way to the moon ✦",
		button: "Open your final surprise ♡"
	},
	letter: {
		greeting: "To my favourite person, Arshmeet,",
		paragraphs: [
			"Happy Birthday,.",
			"It's funny how life works sometimes. I was out there thinking I knew exactly what kind of person I wanted, and then you came along and changed my mind without even trying.",
			"I didn't expect a random Valorant encounter to become something this meaningful. I didn't expect Luffy to become Arshmeet, the person I would miss, care about, get jealous over and smile about.",
			"I love how genuinely good you are as a person. I love your nature, your little ways, your interests and all the things that make you who you are.",
			"I know we haven't met in real life yet. We have our little hidden-face picture, our games, our conversations and the anime we've watched together. But I hope someday we get to make so many more memories, take proper pictures together and experience all those little things we've only imagined.",
			"I might not always express everything perfectly. Sometimes I overthink, sometimes I get jealous, and sometimes I struggle to explain just how much you mean to me.",
			"But one thing I know is that I'm really happy I gave this story a chance.",
			"I hope this year brings you happiness, beautiful experiences, new games and everything your heart wishes for.",
			"Thank you for being you.",
			"Happy Birthday, Arshmeet."
		],
		closing: "With all my love,",
		signature: "Your Hestia ♡",
		end: "To be continued... ♡",
		replay: "Replay our universe",
		tapToOpen: "tap the seal"
	},
	catLines: [
		"mrrp! keep going ♡",
		"she made all this for you",
		"*purrs at Luffy*",
		"I approve of you, human",
		"psst... try tapping things ✦",
		"zzz... oh! hi Luffy"
	],
	hidden: [
		"you found a secret! she smiles every time you text first ♡",
		"secret: she replays your voice notes",
		"this flower says: you're her favourite notification",
		"hidden fact: she still remembers your first message",
		"a tiny star whispers: GG, you won her heart",
		"psst... she thinks you're cute when you rage-quit"
	]
};
var ctx = null;
var master = null;
var musicTimer = null;
var musicEl = null;
function ac() {
	if (!ctx) {
		ctx = new (window.AudioContext || window.webkitAudioContext)();
		master = ctx.createGain();
		master.gain.value = .5;
		master.connect(ctx.destination);
	}
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function tone(freq, start, dur, vol = .08, type = "triangle") {
	const c = ac();
	const o = c.createOscillator();
	const g = c.createGain();
	o.type = type;
	o.frequency.value = freq;
	g.gain.setValueAtTime(0, start);
	g.gain.linearRampToValueAtTime(vol, start + .02);
	g.gain.exponentialRampToValueAtTime(1e-4, start + dur);
	o.connect(g).connect(master);
	o.start(start);
	o.stop(start + dur + .05);
}
var melody = [
	523,
	659,
	784,
	659,
	880,
	784,
	659,
	587,
	523,
	587,
	659,
	523,
	440,
	523,
	587,
	0
];
var bass = [
	131,
	131,
	175,
	175,
	165,
	165,
	147,
	147
];
function startMusic() {
	if (musicTimer) return;
	const c = ac();
	let step = 0;
	const beat = .42;
	let next = c.currentTime + .1;
	musicTimer = window.setInterval(() => {
		while (next < c.currentTime + .6) {
			const n = melody[step % melody.length];
			if (n) tone(n, next, 1.4, .045, "sine");
			if (n) tone(n * 2, next, .6, .012, "triangle");
			if (step % 2 === 0) tone(bass[step / 2 % bass.length], next, 1.6, .03, "sine");
			next += beat;
			step++;
		}
	}, 150);
}
function setMuted(m) {
	if (musicEl) musicEl.muted = m;
	if (master && ctx) master.gain.setTargetAtTime(m ? 0 : .5, ctx.currentTime, .1);
}
var sfx = {
	chime() {
		const t = ac().currentTime;
		[
			1047,
			1319,
			1568,
			2093
		].forEach((f, i) => tone(f, t + i * .07, .6, .05, "sine"));
	},
	unlock() {
		const t = ac().currentTime;
		tone(220, t, .08, .08, "square");
		tone(330, t + .08, .1, .06, "square");
		[
			784,
			988,
			1175
		].forEach((f, i) => tone(f, t + .2 + i * .08, .7, .05, "sine"));
	},
	pop() {
		const t = ac().currentTime;
		tone(880, t, .15, .06, "sine");
		tone(1320, t + .05, .2, .04, "sine");
	},
	paper() {
		const t = ac().currentTime;
		tone(392, t, .3, .04, "triangle");
		tone(523, t + .1, .4, .04, "triangle");
	},
	whoosh() {
		const c = ac();
		const t = c.currentTime;
		const o = c.createOscillator();
		const g = c.createGain();
		o.frequency.setValueAtTime(200, t);
		o.frequency.exponentialRampToValueAtTime(1200, t + .5);
		g.gain.setValueAtTime(.04, t);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .6);
		o.connect(g).connect(master);
		o.start(t);
		o.stop(t + .7);
	},
	celebrate() {
		const t = ac().currentTime;
		[
			523,
			659,
			784,
			1047,
			784,
			1047,
			1319
		].forEach((f, i) => tone(f, t + i * .11, .8, .05, "triangle"));
	}
};
/** Listens to the microphone and calls onBlow when a strong breath is detected. Returns a stop fn. */
async function listenForBlow(onBlow) {
	const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
	const c = ac();
	const src = c.createMediaStreamSource(stream);
	const an = c.createAnalyser();
	an.fftSize = 512;
	src.connect(an);
	const data = new Uint8Array(an.frequencyBinCount);
	let raf = 0;
	let hits = 0;
	const loop = () => {
		an.getByteFrequencyData(data);
		let low = 0;
		for (let i = 0; i < 20; i++) low += data[i];
		low /= 20;
		hits = low > 130 ? hits + 1 : Math.max(0, hits - 1);
		if (hits > 8) {
			stop();
			onBlow();
			return;
		}
		raf = requestAnimationFrame(loop);
	};
	const stop = () => {
		cancelAnimationFrame(raf);
		stream.getTracks().forEach((t) => t.stop());
	};
	loop();
	return stop;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var rand = (a, b) => a + Math.random() * (b - a);
function Starfield({ count = 70, scatter = false }) {
	const stars = (0, import_react.useMemo)(() => Array.from({ length: count }, () => ({
		x: rand(0, 100),
		y: rand(0, 100),
		s: rand(1, 3),
		d: rand(2, 5),
		dl: rand(0, 4)
	})), [count]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		children: [stars.map((st, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
			className: "absolute rounded-full bg-moonlight",
			style: {
				left: `${st.x}%`,
				top: `${st.y}%`,
				width: st.s,
				height: st.s,
				boxShadow: "0 0 6px var(--moonlight)"
			},
			animate: scatter ? {
				x: (st.x - 50) * 30,
				y: (st.y - 50) * 30,
				opacity: 0,
				scale: 2
			} : { opacity: [
				.2,
				1,
				.2
			] },
			transition: scatter ? {
				duration: 1.2,
				ease: "easeIn"
			} : {
				duration: st.d,
				delay: st.dl,
				repeat: Infinity
			}
		}, i)), !scatter && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShootingStars, {})]
	});
}
function ShootingStars() {
	const [k, setK] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setK((v) => v + 1), 5200);
		return () => clearInterval(id);
	}, []);
	const top = (0, import_react.useMemo)(() => rand(5, 40), [k]);
	const left = (0, import_react.useMemo)(() => rand(10, 70), [k]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
		className: "absolute h-px w-24 origin-left rounded-full",
		style: {
			top: `${top}%`,
			left: `${left}%`,
			rotate: 25,
			background: "linear-gradient(90deg, var(--moonlight), transparent)"
		},
		initial: {
			x: 0,
			y: 0,
			opacity: 0
		},
		animate: {
			x: 260,
			y: 120,
			opacity: [
				0,
				1,
				0
			]
		},
		transition: {
			duration: 1.1,
			ease: "easeOut"
		}
	}, k);
}
function Moon({ size = 160, glow = false, withCat = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		className: cn("relative", className),
		style: {
			width: size,
			height: size
		},
		animate: {
			y: [
				0,
				-8,
				0
			],
			filter: glow ? "drop-shadow(0 0 60px var(--moonlight))" : "drop-shadow(0 0 22px color-mix(in oklab, var(--moonlight) 60%, transparent))"
		},
		transition: {
			y: {
				duration: 6,
				repeat: Infinity,
				ease: "easeInOut"
			},
			filter: { duration: .8 }
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 100 100",
			className: "h-full w-full",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mask", {
					id: "crescent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "100",
						height: "100",
						fill: "white"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "64",
						cy: "40",
						r: "38",
						fill: "black"
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "42",
					fill: "var(--moonlight)",
					mask: "url(#crescent)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "26",
					cy: "58",
					r: "3",
					fill: "var(--lavender)",
					opacity: ".5",
					mask: "url(#crescent)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "34",
					cy: "76",
					r: "2",
					fill: "var(--lavender)",
					opacity: ".5",
					mask: "url(#crescent)"
				})
			]
		}), withCat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute",
			style: {
				left: size * .08,
				top: size * .12,
				width: size * .32
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, { variant: "sit" })
		})]
	});
}
/** Cute original cat. variant: sit (blinks) | sleep | party (birthday hat) */
function Cat({ variant = "sit", tone = "var(--cream)", className }) {
	const sleeping = variant === "sleep";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 60 60",
		className: cn("h-auto w-full overflow-visible", className),
		children: [variant === "party" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 14 L30 -4 L38 14 Z",
				fill: "var(--blush)",
				stroke: "var(--night)",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "30",
				cy: "-5",
				r: "3",
				fill: "var(--lavender)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M25 8 L35 8",
				stroke: "var(--lavender)",
				strokeWidth: "2"
			})
		] }), sleeping ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "30",
				cy: "44",
				rx: "24",
				ry: "12",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 44 Q2 34 12 34",
				fill: "none",
				stroke: "var(--night)",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "40",
				cy: "38",
				r: "11",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 31 L33 23 L38 28 M42 28 L47 23 L48 31",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M35 38 q2 2 4 0 M42 38 q2 2 4 0",
				fill: "none",
				stroke: "var(--night)",
				strokeWidth: "1.3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.text, {
				x: "50",
				y: "22",
				fontSize: "8",
				fill: "var(--lavender)",
				animate: {
					opacity: [
						0,
						1,
						0
					],
					y: [22, 12]
				},
				transition: {
					duration: 2.4,
					repeat: Infinity
				},
				children: "z"
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M44 50 Q58 44 52 32",
				fill: "none",
				stroke: "var(--night)",
				strokeWidth: "2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "30",
				cy: "44",
				rx: "16",
				ry: "13",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 18 L18 6 L26 14 M34 14 L42 6 L44 18",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "30",
				cy: "24",
				r: "14",
				fill: tone,
				stroke: "var(--night)",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M19 10 L21 15 M41 10 L39 15",
				stroke: "var(--blush)",
				strokeWidth: "2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.g, {
				animate: { scaleY: [
					1,
					1,
					.1,
					1
				] },
				transition: {
					duration: 4,
					repeat: Infinity,
					times: [
						0,
						.9,
						.95,
						1
					]
				},
				style: { transformOrigin: "30px 23px" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24.5",
					cy: "23",
					r: "2",
					fill: "var(--night)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "35.5",
					cy: "23",
					r: "2",
					fill: "var(--night)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M28 28 q2 2 4 0",
				fill: "none",
				stroke: "var(--night)",
				strokeWidth: "1.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "21",
				cy: "28",
				rx: "2.5",
				ry: "1.4",
				fill: "var(--blush)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "39",
				cy: "28",
				rx: "2.5",
				ry: "1.4",
				fill: "var(--blush)"
			})
		] })]
	});
}
function Cloud({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		className: cn("pointer-events-none absolute", className),
		animate: { x: [
			0,
			14,
			0
		] },
		transition: {
			duration: 9,
			repeat: Infinity,
			ease: "easeInOut"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 120 50",
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20 45 Q2 45 8 32 Q4 18 22 20 Q28 4 48 12 Q62 0 78 12 Q100 8 100 26 Q118 30 108 45 Z",
					fill: "var(--moonlight)",
					opacity: ".9"
				})
			}), children && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute -top-[30%] left-1/2 w-[45%] -translate-x-1/2",
				children
			})]
		})
	});
}
function FloatingHearts({ count = 10, className }) {
	const hearts = (0, import_react.useMemo)(() => Array.from({ length: count }, () => ({
		x: rand(0, 100),
		s: rand(10, 22),
		d: rand(8, 16),
		dl: rand(0, 10)
	})), [count]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute inset-0 overflow-hidden", className),
		children: hearts.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
			className: "absolute bottom-0 text-blush",
			style: {
				left: `${h.x}%`,
				fontSize: h.s
			},
			initial: {
				y: 40,
				opacity: 0
			},
			animate: {
				y: "-110vh",
				opacity: [
					0,
					.8,
					.8,
					0
				],
				x: [
					0,
					20,
					-20,
					0
				]
			},
			transition: {
				duration: h.d,
				delay: h.dl,
				repeat: Infinity,
				ease: "linear"
			},
			children: "♡"
		}, i))
	});
}
function Petals({ count = 16 }) {
	const ps = (0, import_react.useMemo)(() => Array.from({ length: count }, () => ({
		x: rand(0, 100),
		s: rand(8, 16),
		d: rand(9, 18),
		dl: rand(0, 10),
		r: rand(-180, 180)
	})), [count]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		children: ps.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
			className: "absolute top-0 block rounded-[60%_0_60%_0] bg-blush",
			style: {
				left: `${p.x}%`,
				width: p.s,
				height: p.s * .8,
				opacity: .85
			},
			initial: {
				y: -30,
				rotate: 0
			},
			animate: {
				y: "110vh",
				x: [
					0,
					40,
					-20,
					30
				],
				rotate: p.r * 4
			},
			transition: {
				duration: p.d,
				delay: p.dl,
				repeat: Infinity,
				ease: "linear"
			}
		}, i))
	});
}
function GlowButton({ children, onClick, className, variant = "night" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
		onClick,
		whileHover: { scale: 1.04 },
		whileTap: { scale: .96 },
		className: cn("relative rounded-full px-7 py-3 font-body text-base font-semibold tracking-wide transition-shadow", variant === "night" ? "border border-lavender/60 bg-lavender/15 text-moonlight shadow-glow backdrop-blur-sm hover:bg-lavender/25" : "bg-night text-cream shadow-soft hover:shadow-glow", className),
		children
	});
}
function Popup({ open, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-night/50 p-6 backdrop-blur-[2px]",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			onClick: (e) => e.stopPropagation(),
			className: "paper relative max-w-sm rounded-2xl p-7 text-center text-night shadow-soft",
			initial: {
				scale: .6,
				rotate: -6,
				y: 30
			},
			animate: {
				scale: 1,
				rotate: -1,
				y: 0
			},
			exit: {
				scale: .7,
				opacity: 0
			},
			transition: {
				type: "spring",
				stiffness: 260,
				damping: 18
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tape" }),
				children,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "mt-5 font-hand text-xl text-night/60 hover:text-night",
					children: "close ♡"
				})
			]
		})
	}) });
}
/** A small object that hides a secret message. */
function Secret({ index, className, children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
		"aria-label": "hidden surprise",
		className: cn("absolute z-10 cursor-pointer select-none", className),
		animate: {
			scale: [
				1,
				1.15,
				1
			],
			opacity: [
				.7,
				1,
				.7
			]
		},
		transition: {
			duration: 3,
			repeat: Infinity,
			delay: index * .4
		},
		whileHover: { scale: 1.4 },
		onClick: () => {
			sfx.pop();
			setOpen(true);
		},
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {
		open,
		onClose: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-hand text-2xl leading-snug",
			children: content.hidden[index % content.hidden.length]
		})
	})] });
}
function Confetti({ fire }) {
	const pieces = (0, import_react.useMemo)(() => Array.from({ length: 90 }, () => ({
		x: rand(-50, 50),
		y: rand(-90, -30),
		r: rand(0, 720),
		c: [
			"var(--blush)",
			"var(--lavender)",
			"var(--cream)",
			"var(--gold)",
			"var(--moonlight)"
		][Math.floor(rand(0, 5))],
		w: rand(6, 11),
		d: rand(1.6, 3)
	})), [fire]);
	if (!fire) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-0 z-40 overflow-hidden",
		children: pieces.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
			className: "absolute left-1/2 top-1/2 block rounded-sm",
			style: {
				width: p.w,
				height: p.w * .5,
				background: p.c
			},
			initial: {
				x: 0,
				y: 0,
				opacity: 1
			},
			animate: {
				x: `${p.x}vw`,
				y: [
					`0vh`,
					`${p.y}vh`,
					`60vh`
				],
				rotate: p.r,
				opacity: [
					1,
					1,
					0
				]
			},
			transition: {
				duration: p.d,
				ease: "easeOut"
			}
		}, i))
	}, fire);
}
function Shell({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("relative min-h-[100dvh] w-full overflow-hidden", className),
		children
	});
}
var fadeUp = (delay = 0) => ({
	initial: {
		opacity: 0,
		y: 24
	},
	animate: {
		opacity: 1,
		y: 0
	},
	transition: {
		duration: .9,
		delay,
		ease: [
			.22,
			1,
			.36,
			1
		]
	}
});
function IntroScene({ onNext, onFirstTap }) {
	const [leaving, setLeaving] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex items-center justify-center bg-night",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {
				count: 90,
				scatter: leaving
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, {
				className: "bottom-[8%] left-[-4%] w-44 opacity-80 sm:w-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
					variant: "sleep",
					tone: "var(--blush)"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "right-[-6%] top-[14%] w-36 opacity-60 sm:w-52" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 4,
				className: "right-[12%] top-[62%] text-xl text-lavender",
				children: "✦"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex flex-col items-center px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
						size: 170,
						glow: leaving,
						withCat: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h1, {
						...fadeUp(.3),
						className: "mt-8 font-display text-5xl font-semibold italic text-moonlight sm:text-7xl",
						children: content.intro.greeting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						...fadeUp(.7),
						className: "mt-4 max-w-md font-hand text-2xl text-lavender sm:text-3xl",
						children: content.intro.line
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						...fadeUp(1.1),
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowButton, {
							onClick: () => {
								if (leaving) return;
								onFirstTap();
								sfx.whoosh();
								setLeaving(true);
								setTimeout(onNext, 1300);
							},
							className: "animate-pulse-glow",
							children: content.intro.button
						})
					})
				]
			})
		]
	});
}
function KeyArt({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 60 130",
		className: "h-full w-full overflow-visible",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "27",
				y: "50",
				width: "6",
				height: "70",
				rx: "3",
				fill: "var(--cream)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "33",
				y: "98",
				width: "12",
				height: "6",
				rx: "2",
				fill: "var(--cream)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "33",
				y: "110",
				width: "8",
				height: "6",
				rx: "2",
				fill: "var(--cream)"
			}),
			kind === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "30",
					cy: "28",
					r: "24",
					fill: "var(--moonlight)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "22",
					r: "20",
					fill: "var(--night)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "38",
					cy: "40",
					r: "2",
					fill: "var(--gold)"
				})
			] }),
			kind === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M30 52 C-6 30 6 0 30 16 C54 0 66 30 30 52 Z",
				fill: "var(--blush)"
			}),
			kind === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M8 22 L10 0 L24 12 M36 12 L50 0 L52 22",
					fill: "var(--lavender)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "30",
					cy: "28",
					r: "23",
					fill: "var(--lavender)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "22",
					cy: "27",
					r: "2.5",
					fill: "var(--night)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "38",
					cy: "27",
					r: "2.5",
					fill: "var(--night)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M27 33 q3 3 6 0",
					stroke: "var(--night)",
					strokeWidth: "1.6",
					fill: "none",
					strokeLinecap: "round"
				})
			] })
		]
	});
}
function KeysScene({ onNext }) {
	const [unlocked, setUnlocked] = (0, import_react.useState)([]);
	const [unlocking, setUnlocking] = (0, import_react.useState)(null);
	const [openCard, setOpenCard] = (0, import_react.useState)(null);
	const all = unlocked.length === 3;
	const tap = (i) => {
		if (unlocking !== null) return;
		if (unlocked.includes(i)) return setOpenCard(i);
		sfx.unlock();
		setUnlocking(i);
		setTimeout(() => {
			setUnlocked((u) => [...u, i]);
			setUnlocking(null);
			setOpenCard(i);
		}, 1e3);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center justify-center bg-night px-5 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: 60 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 0,
				className: "left-[8%] top-[20%] text-lg text-blush",
				children: "✿"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h2, {
				...fadeUp(.1),
				className: "relative z-10 max-w-2xl text-center font-display text-3xl italic text-moonlight sm:text-5xl",
				children: content.keys.heading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
				...fadeUp(.4),
				className: "relative z-10 mt-3 font-hand text-xl text-lavender",
				children: content.keys.hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mt-14 flex flex-wrap items-end justify-center gap-8 sm:gap-16",
				children: [
					0,
					1,
					2
				].map((i) => {
					const done = unlocked.includes(i);
					const isUnlocking = unlocking === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						onClick: () => tap(i),
						className: "group flex flex-col items-center",
						initial: {
							opacity: 0,
							y: 40
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: .5 + i * .2 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							className: "relative h-32 w-16 sm:h-40 sm:w-20",
							animate: isUnlocking ? {
								rotate: [
									0,
									-25,
									90
								],
								scale: [
									1,
									1.2,
									1.1
								]
							} : {
								y: [
									0,
									-12,
									0
								],
								rotate: [
									-4,
									4,
									-4
								]
							},
							transition: isUnlocking ? { duration: .9 } : {
								duration: 4 + i,
								repeat: Infinity,
								ease: "easeInOut"
							},
							style: { filter: done || isUnlocking ? "drop-shadow(0 0 18px var(--gold))" : "drop-shadow(0 0 10px color-mix(in oklab, var(--lavender) 70%, transparent))" },
							whileHover: { scale: 1.1 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyArt, { kind: i }), isUnlocking && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
								className: "absolute inset-0 rounded-full",
								initial: {
									scale: .3,
									opacity: 1
								},
								animate: {
									scale: 2.4,
									opacity: 0
								},
								transition: { duration: .9 },
								style: { boxShadow: "0 0 0 3px var(--gold)" }
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("mt-4 font-hand text-xl transition-colors", done ? "text-gold" : "text-moonlight/80"),
							children: [done ? "✓ " : "", content.keys.labels[i]]
						})]
					}, i);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mt-12 h-14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: all && openCard === null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						scale: .8
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowButton, {
						onClick: onNext,
						children: content.keys.continue
					})
				}) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: openCard !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryCard, {
				index: openCard,
				onClose: () => setOpenCard(null)
			}) })
		]
	});
}
function Crosshair() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.svg, {
		viewBox: "0 0 40 40",
		className: "h-12 w-12",
		animate: {
			rotate: [
				0,
				90,
				90,
				0
			],
			scale: [
				1,
				.85,
				1
			]
		},
		transition: {
			duration: 3,
			repeat: Infinity
		},
		children: [[
			[
				20,
				4,
				20,
				14
			],
			[
				20,
				26,
				20,
				36
			],
			[
				4,
				20,
				14,
				20
			],
			[
				26,
				20,
				36,
				20
			]
		].map(([a, b, c, d], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: a,
			y1: b,
			x2: c,
			y2: d,
			stroke: "var(--crosshair)",
			strokeWidth: "3",
			strokeLinecap: "round"
		}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "20",
			cy: "20",
			r: "2",
			fill: "var(--crosshair)"
		})]
	});
}
function PixelHeart({ delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.svg, {
		viewBox: "0 0 7 6",
		className: "h-6 w-7",
		style: { shapeRendering: "crispEdges" },
		animate: { y: [
			0,
			-6,
			0
		] },
		transition: {
			duration: 1.6,
			repeat: Infinity,
			delay
		},
		children: [
			"0110110",
			"1111111",
			"1111111",
			"0111110",
			"0011100",
			"0001000"
		].flatMap((row, y) => row.split("").map((c, x) => c === "1" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x,
			y,
			width: "1",
			height: "1",
			fill: "var(--pixel)"
		}, `${x}-${y}`) : null))
	});
}
function AnimeTile({ title, image, variant }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-cream p-2 shadow-soft",
		style: { rotate: variant ? "2deg" : "-2deg" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: image,
			alt: title,
			className: "aspect-[8/5] w-full rounded object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-center font-hand text-lg leading-tight text-night",
			children: title
		})]
	});
}
function StoryCard({ index, onClose }) {
	const card = content.cards[index];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		className: "fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-night/70 p-4 backdrop-blur-sm",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		onClick: onClose,
		children: [index === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Petals, { count: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
			onClick: (e) => e.stopPropagation(),
			className: cn("paper relative my-8 w-full max-w-lg rounded-2xl p-7 text-night shadow-soft sm:p-10", index === 1 && "paper-blush"),
			initial: {
				rotateY: 90,
				scale: .8,
				opacity: 0
			},
			animate: {
				rotateY: 0,
				scale: 1,
				opacity: 1,
				rotate: index === 1 ? 1 : -1
			},
			exit: {
				rotateY: -90,
				opacity: 0
			},
			transition: {
				type: "spring",
				stiffness: 120,
				damping: 16
			},
			style: { transformPerspective: 1e3 },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tape" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-hand text-lg text-night/50",
					children: [
						"little card ",
						index + 1,
						" / 3"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl font-semibold italic leading-tight sm:text-4xl",
							children: card.title
						}),
						index === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, {}),
						index === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
							className: "text-3xl text-blush-deep",
							animate: { scale: [
								1,
								1.2,
								1
							] },
							transition: {
								duration: 1.4,
								repeat: Infinity
							},
							children: "♡"
						}),
						index === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-3xl",
							children: "🌸"
						})
					]
				}),
				index === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex gap-2",
					children: [
						0,
						1,
						2
					].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixelHeart, { delay: i * .2 }, i))
				}),
				"shows" in card && card.shows && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid grid-cols-2 gap-4",
					children: card.shows.map((show, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimeTile, {
						...show,
						variant: i
					}, show.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 space-y-4",
					children: card.body.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: .4 + i * (index === 1 ? .9 : .35) },
						className: cn("font-body leading-relaxed", index === 1 && i === card.body.length - 1 && "font-hand text-2xl text-blush-deep", index === 2 && "font-hand text-2xl leading-snug"),
						children: p
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "mt-7 font-hand text-xl text-night/60 hover:text-night",
					children: "tuck it away ♡"
				})
			]
		})]
	});
}
var STAR_POS = [
	[50, 30],
	[30, 18],
	[14, 32],
	[22, 56],
	[50, 82],
	[78, 56],
	[86, 32],
	[70, 18]
];
function StarsScene({ onNext }) {
	const [found, setFound] = (0, import_react.useState)([]);
	const [open, setOpen] = (0, import_react.useState)(null);
	const msgs = content.stars.messages;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center bg-night px-4 pb-16 pt-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: 70 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 1,
				className: "bottom-[10%] left-[8%] text-lg text-lavender",
				children: "✧"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 5,
				className: "right-[6%] top-[14%] text-lg text-blush",
				children: "✿"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h2, {
				...fadeUp(),
				className: "relative z-10 max-w-xl text-center font-display text-3xl italic text-moonlight sm:text-5xl",
				children: content.stars.heading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "relative z-10 mt-2 font-hand text-xl text-lavender",
				children: [
					content.stars.hint,
					" · ",
					found.length,
					"/",
					msgs.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mt-6 aspect-square w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 100 100",
						className: "absolute inset-0 h-full w-full",
						children: STAR_POS.map(([x, y], i) => {
							const [x2, y2] = STAR_POS[(i + 1) % STAR_POS.length];
							const show = found.includes(i) && found.includes((i + 1) % STAR_POS.length);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.line, {
								x1: x,
								y1: y,
								x2,
								y2,
								stroke: "var(--lavender)",
								strokeWidth: ".4",
								strokeDasharray: "1 1",
								initial: { pathLength: 0 },
								animate: {
									pathLength: show ? 1 : 0,
									opacity: show ? .8 : 0
								},
								transition: { duration: .8 }
							}, i);
						})
					}),
					STAR_POS.slice(0, msgs.length).map(([x, y], i) => {
						const f = found.includes(i);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							"aria-label": `star ${i + 1}`,
							className: "absolute -translate-x-1/2 -translate-y-1/2 p-2",
							style: {
								left: `${x}%`,
								top: `${y}%`
							},
							animate: { scale: f ? 1.1 : [
								1,
								1.25,
								1
							] },
							transition: {
								duration: 2 + i % 3,
								repeat: f ? 0 : Infinity
							},
							whileHover: { scale: 1.4 },
							onClick: () => {
								sfx.chime();
								setFound((s) => s.includes(i) ? s : [...s, i]);
								setOpen(i);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 24 24",
								className: "h-7 w-7 sm:h-9 sm:w-9",
								style: { filter: `drop-shadow(0 0 ${f ? 10 : 5}px var(--${f ? "gold" : "moonlight"}))` },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M12 1 L14.6 9.4 L23 12 L14.6 14.6 L12 23 L9.4 14.6 L1 12 L9.4 9.4 Z",
									fill: f ? "var(--gold)" : "var(--moonlight)"
								})
							})
						}, i);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: found.length === msgs.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "absolute left-1/2 top-[52%] -translate-x-1/2 -translate-y-1/2 font-hand text-2xl text-blush",
						initial: { scale: 0 },
						animate: { scale: 1 },
						children: "all of you ♡"
					}) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mt-4 h-14",
				children: found.length === msgs.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowButton, {
						onClick: onNext,
						children: content.stars.continue
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popup, {
				open: open !== null,
				onClose: () => setOpen(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-hand text-lg text-night/50",
					children: ["things I love about you #", (open ?? 0) + 1]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-3xl italic leading-snug",
					children: open !== null && msgs[open]
				})]
			})
		]
	});
}
function MemoryScene({ onNext }) {
	const [photo, setPhoto] = (0, import_react.useState)("");
	const input = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		{
			const saved = localStorage.getItem("our-photo");
			if (saved) setPhoto(saved);
		}
	}, []);
	const pick = (f) => {
		if (!f) return;
		const r = new FileReader();
		r.onload = () => {
			const url = String(r.result);
			setPhoto(url);
			try {
				localStorage.setItem("our-photo", url);
			} catch {}
		};
		r.readAsDataURL(f);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center justify-center bg-lavender-night px-5 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: 40 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingHearts, { count: 12 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 2,
				className: "left-[10%] top-[30%] text-2xl",
				children: "🌷"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h2, {
				...fadeUp(),
				className: "relative z-10 text-center font-display text-3xl italic text-moonlight sm:text-5xl",
				children: content.memory.heading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				className: "relative z-10 mt-10 w-72 bg-cream p-4 pb-20 shadow-soft sm:w-80",
				initial: {
					opacity: 0,
					y: 60,
					rotate: -14
				},
				animate: {
					opacity: 1,
					y: 0,
					rotate: -3
				},
				transition: {
					type: "spring",
					stiffness: 60,
					damping: 12,
					delay: .3
				},
				whileHover: {
					rotate: 0,
					scale: 1.03
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tape" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => input.current?.click(),
						className: "group relative block aspect-square w-full overflow-hidden bg-night/90",
						children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: photo,
							alt: "Our hidden-face picture",
							className: "h-full w-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full flex-col items-center justify-center gap-3 border-2 border-dashed border-lavender/50 p-6 text-center text-lavender",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-10 w-10" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-hand text-xl",
									children: content.memory.placeholder
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-body text-xs opacity-70",
									children: "tap to add the photo"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: input,
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: (e) => pick(e.target.files?.[0])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-5 left-0 right-0 px-4 text-center font-hand text-2xl leading-tight text-night",
						children: content.memory.caption
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
				...fadeUp(1.2),
				className: "relative z-10 mt-10 max-w-md text-center font-hand text-2xl leading-snug text-blush sm:text-3xl",
				children: content.memory.hope
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				...fadeUp(1.8),
				className: "relative z-10 mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowButton, {
					onClick: onNext,
					children: content.memory.continue
				})
			})
		]
	});
}
function Envelope({ open, onOpen, label, seal = false, tone = "var(--blush)" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
		onClick: onOpen,
		className: "relative block h-48 w-72 sm:h-56 sm:w-80",
		animate: open ? {} : { y: [
			0,
			-6,
			0
		] },
		transition: {
			duration: 3,
			repeat: Infinity
		},
		whileHover: open ? {} : {
			scale: 1.04,
			rotate: -1
		},
		style: { perspective: 800 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 rounded-lg shadow-soft",
				style: { background: tone }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 320 224",
				preserveAspectRatio: "none",
				className: "absolute inset-0 h-full w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 224 L160 110 L320 224 Z",
					fill: "color-mix(in oklab, var(--cream) 70%, transparent)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 0 L140 120 M320 0 L180 120",
					stroke: "color-mix(in oklab, var(--night) 15%, transparent)",
					strokeWidth: "2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				className: "absolute left-0 right-0 top-0 h-1/2 origin-top",
				animate: { rotateX: open ? 180 : 0 },
				transition: { duration: .7 },
				style: { transformStyle: "preserve-3d" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 320 112",
					preserveAspectRatio: "none",
					className: "h-full w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 0 L160 112 L320 0 Z",
						fill: "color-mix(in oklab, var(--night) 12%, var(--cream))"
					})
				})
			}),
			seal && !open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				className: "absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-wax text-2xl text-cream shadow-soft",
				animate: { scale: [
					1,
					1.08,
					1
				] },
				transition: {
					duration: 1.6,
					repeat: Infinity
				},
				children: "♥"
			}),
			!open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute -bottom-12 left-0 right-0 text-center font-hand text-2xl text-moonlight",
				children: label
			})
		]
	});
}
function ConfessionScene({ onNext }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center justify-center bg-night px-5 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: 50 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 3,
				className: "right-[10%] top-[18%] text-xl text-gold",
				children: "☾"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: !open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					exit: {
						y: 40,
						opacity: 0
					},
					className: "relative z-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Envelope, {
						open: false,
						label: content.confession.envelope,
						onOpen: () => {
							sfx.paper();
							setOpen(true);
						}
					})
				}, "env") : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					className: "paper relative z-10 w-full max-w-lg rounded-xl p-7 text-night shadow-soft sm:p-10",
					initial: {
						y: 120,
						scaleY: .2,
						opacity: 0
					},
					animate: {
						y: 0,
						scaleY: 1,
						opacity: 1,
						rotate: -1
					},
					transition: {
						type: "spring",
						stiffness: 80,
						damping: 14
					},
					style: { originY: 1 },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tape" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-hand text-xl text-night/50",
							children: "a little secret…"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-4",
							children: content.confession.body.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
								initial: { opacity: 0 },
								animate: { opacity: 1 },
								transition: { delay: .6 + i * .8 },
								className: "font-hand text-2xl leading-snug",
								children: p
							}, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							className: "mt-6 flex items-center justify-between",
							initial: { opacity: 0 },
							animate: { opacity: 1 },
							transition: { delay: 3.2 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-14",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
									variant: "sit",
									tone: "var(--blush)"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowButton, {
								variant: "paper",
								onClick: onNext,
								children: content.confession.continue
							})]
						})
					]
				}, "note")
			})
		]
	});
}
function Balloon({ x, color, delay }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		className: "pointer-events-none absolute bottom-0 w-12 sm:w-16",
		style: { left: x },
		initial: { y: "100%" },
		animate: { y: [
			"10vh",
			"-8vh",
			"-2vh",
			"-8vh"
		] },
		transition: {
			duration: 8,
			delay,
			repeat: Infinity,
			repeatType: "mirror",
			ease: "easeInOut"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 40 90",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "20",
					cy: "20",
					rx: "16",
					ry: "20",
					fill: color
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "14",
					cy: "13",
					rx: "4",
					ry: "6",
					fill: "var(--cream)",
					opacity: ".5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20 40 Q15 60 22 90",
					stroke: "var(--night)",
					strokeOpacity: ".4",
					fill: "none"
				})
			]
		})
	});
}
function Candle({ lit, onBlow, i }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: onBlow,
		"aria-label": "blow out candle",
		className: "relative flex w-6 flex-col items-center sm:w-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative h-10 w-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: lit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					className: "absolute bottom-0 left-1/2 -translate-x-1/2",
					exit: {
						scaleY: 0,
						opacity: 0
					},
					transition: { duration: .3 },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "h-8 w-4 rounded-[50%_50%_50%_50%/60%_60%_40%_40%]",
						style: {
							background: "radial-gradient(circle at 50% 70%, var(--cream) 0 25%, var(--gold) 45%, var(--flame) 80%)",
							boxShadow: "0 0 18px 6px color-mix(in oklab, var(--gold) 55%, transparent)",
							transformOrigin: "bottom"
						},
						animate: {
							scaleY: [
								1,
								1.15,
								.92,
								1.08,
								1
							],
							rotate: [
								-3,
								3,
								-2,
								2,
								-3
							],
							scaleX: [
								1,
								.9,
								1.05,
								1
							]
						},
						transition: {
							duration: .9 + i * .1,
							repeat: Infinity
						}
					})
				}, "f") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					className: "absolute bottom-0 left-1/2 h-3 w-1 -translate-x-1/2 rounded-full bg-night/30",
					initial: {
						y: 0,
						opacity: .8
					},
					animate: {
						y: -30,
						opacity: 0,
						scaleX: 3
					},
					transition: { duration: 1.4 }
				}, "s") })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 w-px bg-night" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-12 w-4 rounded-sm",
				style: { background: `repeating-linear-gradient(135deg, var(--cream) 0 5px, ${i % 2 ? "var(--lavender)" : "var(--blush-deep)"} 5px 9px)` }
			})
		]
	});
}
function CakeScene({ onNext }) {
	const [lit, setLit] = (0, import_react.useState)(Array(5).fill(true));
	const [burst, setBurst] = (0, import_react.useState)(0);
	const [micOn, setMicOn] = (0, import_react.useState)(false);
	const stopMic = (0, import_react.useRef)(null);
	const out = lit.every((l) => !l);
	(0, import_react.useEffect)(() => {
		if (out && !burst) {
			sfx.celebrate();
			setBurst(1);
			setTimeout(() => setBurst(2), 900);
			stopMic.current?.();
		}
	}, [out, burst]);
	(0, import_react.useEffect)(() => () => stopMic.current?.(), []);
	const blow = (i) => {
		if (!lit[i]) return;
		sfx.pop();
		setLit((l) => l.map((v, j) => j === i ? false : v));
	};
	const useMic = async () => {
		try {
			setMicOn(true);
			stopMic.current = await listenForBlow(() => {
				lit.forEach((_, i) => setTimeout(() => setLit((l) => l.map((v, j) => j === i ? false : v)), i * 120));
				setMicOn(false);
			});
		} catch {
			setMicOn(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center justify-center bg-party px-4 py-16 text-night",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
				size: 110,
				className: "absolute right-[6%] top-[5%] opacity-90"
			}),
			Array.from({ length: 14 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
				className: "absolute text-lavender",
				style: {
					left: `${i * 37 % 100}%`,
					top: `${i * 23 % 50}%`
				},
				animate: {
					opacity: [
						.3,
						1,
						.3
					],
					scale: [
						.8,
						1.2,
						.8
					]
				},
				transition: {
					duration: 2 + i % 3,
					repeat: Infinity
				},
				children: "✦"
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balloon, {
				x: "3%",
				color: "var(--blush-deep)",
				delay: 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balloon, {
				x: "14%",
				color: "var(--lavender)",
				delay: 1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balloon, {
				x: "80%",
				color: "var(--blush-deep)",
				delay: .5
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balloon, {
				x: "90%",
				color: "var(--lavender)",
				delay: 1.5
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secret, {
				index: 4,
				className: "bottom-[6%] right-[30%] text-2xl",
				children: "🌸"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h2, {
				...fadeUp(),
				className: "relative z-10 text-center font-display text-4xl font-bold tracking-wide sm:text-6xl",
				children: content.cake.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
				...fadeUp(.4),
				className: "relative z-10 mt-3 max-w-lg text-center font-hand text-2xl leading-snug text-night/80",
				children: content.cake.line
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mt-8 flex items-end gap-2 sm:gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "w-16 sm:w-20",
						animate: { rotate: [
							-4,
							4,
							-4
						] },
						transition: {
							duration: 2,
							repeat: Infinity
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, { variant: "party" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-3 sm:gap-4",
							children: lit.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Candle, {
								i,
								lit: l,
								onBlow: () => blow(i)
							}, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 240 170",
							className: "-mt-1 w-60 sm:w-72",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "40",
									y: "0",
									width: "160",
									height: "60",
									rx: "10",
									fill: "var(--blush)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M40 14 Q60 30 80 14 T120 14 T160 14 T200 14 V8 Q200 0 190 0 H50 Q40 0 40 8Z",
									fill: "var(--cream)"
								}),
								[
									60,
									100,
									140,
									180
								].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: x,
									cy: "40",
									r: "4",
									fill: "var(--blush-deep)"
								}, x)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "15",
									y: "60",
									width: "210",
									height: "80",
									rx: "12",
									fill: "var(--lavender)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M15 74 Q40 96 65 74 T115 74 T165 74 T225 74 V70 Q225 60 213 60 H27 Q15 60 15 72Z",
									fill: "var(--cream)"
								}),
								[
									45,
									90,
									135,
									180
								].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: `M${x} 115 c-6 -8 6 -12 6 -4 c0 -8 12 -4 6 4 l-6 6z`,
									fill: "var(--blush-deep)"
								}, x)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
									cx: "120",
									cy: "150",
									rx: "118",
									ry: "14",
									fill: "var(--cream)",
									stroke: "var(--night)",
									strokeOpacity: ".15"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "w-16 sm:w-20",
						animate: { rotate: [
							4,
							-4,
							4
						] },
						transition: {
							duration: 2.4,
							repeat: Infinity
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
							variant: "party",
							tone: "var(--blush)"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mt-6 flex min-h-24 flex-col items-center gap-3 text-center",
				children: !out ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl italic",
						children: content.cake.instruction
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-body text-sm text-night/60",
						children: ["tap each flame", typeof navigator !== "undefined" && navigator.mediaDevices ? "" : ""]
					}),
					typeof navigator !== "undefined" && !!navigator.mediaDevices?.getUserMedia && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: useMic,
						disabled: micOn,
						className: "inline-flex items-center gap-2 rounded-full border border-night/20 px-4 py-1.5 font-body text-sm hover:bg-night/5 disabled:opacity-60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-4 w-4" }),
							" ",
							micOn ? "listening… blow!" : content.cake.mic
						]
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					className: "font-hand text-2xl",
					children: content.cake.done
				}), burst === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						scale: .8
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GlowButton, {
						variant: "paper",
						onClick: onNext,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-2 inline h-4 w-4" }), content.cake.button]
					})
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confetti, { fire: burst ? 1 : 0 })
		]
	});
}
function LetterScene({ onReplay }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const L = content.letter;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		className: "flex flex-col items-center bg-night px-4 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: 60 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingHearts, { count: 8 }),
			!open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				className: "relative z-10 mt-[20vh]",
				initial: {
					scale: .6,
					opacity: 0
				},
				animate: {
					scale: 1,
					opacity: 1
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Envelope, {
					open: false,
					seal: true,
					tone: "var(--cream)",
					label: L.tapToOpen,
					onOpen: () => {
						sfx.paper();
						setOpen(true);
					}
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
				className: "paper relative z-10 w-full max-w-2xl rounded-md px-6 py-10 text-night shadow-soft sm:px-14 sm:py-14",
				initial: {
					scaleY: .05,
					opacity: 0
				},
				animate: {
					scaleY: 1,
					opacity: 1
				},
				transition: {
					duration: 1.1,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				style: { originY: 0 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						...fadeUp(.8),
						className: "font-display text-3xl italic sm:text-4xl",
						children: L.greeting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 space-y-5",
						children: L.paragraphs.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
							initial: {
								opacity: 0,
								y: 12
							},
							whileInView: {
								opacity: 1,
								y: 0
							},
							viewport: {
								once: true,
								margin: "-40px"
							},
							transition: { duration: .8 },
							className: "font-hand text-[1.45rem] leading-snug sm:text-2xl",
							children: p
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-hand text-2xl",
							children: L.closing
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
							className: "mt-1 overflow-hidden whitespace-nowrap font-signature text-5xl text-blush-deep sm:text-6xl",
							initial: { clipPath: "inset(0 100% 0 0)" },
							whileInView: { clipPath: "inset(0 0% 0 0)" },
							viewport: { once: true },
							transition: {
								duration: 2.4,
								ease: "easeInOut",
								delay: .3
							},
							children: L.signature
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-20 shrink-0 sm:w-24",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, {
								variant: "sleep",
								tone: "var(--lavender)"
							})
						})]
					})
				]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				className: "relative z-10 mt-14 flex flex-col items-center gap-6",
				initial: { opacity: 0 },
				whileInView: { opacity: 1 },
				viewport: { once: true },
				transition: { duration: 1.5 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl italic text-moonlight",
					children: L.end
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GlowButton, {
					onClick: onReplay,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "mr-2 inline h-4 w-4" }), L.replay]
				})]
			})
		]
	});
}
var SCENES = [
	"intro",
	"keys",
	"stars",
	"memory",
	"confession",
	"cake",
	"letter"
];
var LABELS = [
	"invitation",
	"keys",
	"stars",
	"memory",
	"secret",
	"cake",
	"letter"
];
function Universe() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)(0);
	const [muted, setMute] = (0, import_react.useState)(false);
	const [musicStarted, setMusicStarted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const go = (n) => {
		setStep(n);
		window.scrollTo({ top: 0 });
	};
	const next = () => go(Math.min(step + 1, SCENES.length - 1));
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-screen bg-night" });
	const scene = SCENES[step];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-[100dvh] bg-night font-body",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						filter: "blur(10px)",
						scale: 1.03
					},
					animate: {
						opacity: 1,
						filter: "blur(0px)",
						scale: 1
					},
					exit: {
						opacity: 0,
						filter: "blur(10px)",
						scale: .98
					},
					transition: { duration: .8 },
					children: [
						scene === "intro" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroScene, {
							onNext: next,
							onFirstTap: () => {
								startMusic();
								setMuted(muted);
								setMusicStarted(true);
							}
						}),
						scene === "keys" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeysScene, { onNext: next }),
						scene === "stars" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarsScene, { onNext: next }),
						scene === "memory" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryScene, { onNext: next }),
						scene === "confession" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfessionScene, { onNext: next }),
						scene === "cake" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CakeScene, { onNext: next }),
						scene === "letter" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterScene, { onReplay: () => go(0) })
					]
				}, scene)
			}),
			step > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				step,
				light: scene === "cake"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": muted ? "Unmute music" : "Mute music",
				onClick: () => {
					if (!musicStarted) {
						startMusic();
						setMusicStarted(true);
					}
					setMute(!muted);
					setMuted(!muted);
				},
				className: "fixed right-4 top-4 z-40 flex h-11 w-11 items-center justify-center rounded-full border border-lavender/50 bg-night/70 text-moonlight shadow-glow backdrop-blur hover:bg-night",
				children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-5 w-5" })
			}),
			step > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Companion, {})
		]
	});
}
function Progress({ step, light }) {
	const total = SCENES.length - 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed left-1/2 top-5 z-30 flex -translate-x-1/2 flex-col items-center gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5 rounded-full bg-night/60 px-3 py-2 backdrop-blur",
			children: [Array.from({ length: total }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
				className: "block h-1.5 rounded-full",
				animate: {
					width: i + 1 === step ? 22 : 8,
					backgroundColor: i < step ? "var(--gold)" : "color-mix(in oklab, var(--moonlight) 30%, transparent)"
				}
			}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 text-xs",
				children: "🌙"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `font-hand text-sm ${light ? "text-night/60" : "text-lavender/80"}`,
			children: LABELS[step]
		})]
	});
}
/** Tiny cat that follows the cursor (desktop) or floats in a corner (mobile), sleeps & chats. */
function Companion() {
	const x = useMotionValue(typeof window !== "undefined" ? window.innerWidth - 90 : 0);
	const y = useMotionValue(typeof window !== "undefined" ? window.innerHeight - 110 : 0);
	const sx = useSpring(x, {
		stiffness: 40,
		damping: 14
	});
	const sy = useSpring(y, {
		stiffness: 40,
		damping: 14
	});
	const [fine, setFine] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [sleep, setSleep] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const isFine = window.matchMedia("(pointer: fine)").matches;
		setFine(isFine);
		let idle;
		const wake = () => {
			setSleep(false);
			clearTimeout(idle);
			idle = window.setTimeout(() => setSleep(true), 9e3);
		};
		const move = (e) => {
			x.set(e.clientX + 24);
			y.set(e.clientY + 18);
			wake();
		};
		if (isFine) window.addEventListener("pointermove", move);
		else {
			x.set(16);
			y.set(window.innerHeight - 96);
		}
		wake();
		const talk = window.setInterval(() => {
			setMsg(content.catLines[Math.floor(Math.random() * content.catLines.length)]);
			setTimeout(() => setMsg(null), 3500);
		}, 14e3);
		return () => {
			window.removeEventListener("pointermove", move);
			clearInterval(talk);
			clearTimeout(idle);
		};
	}, [x, y]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		className: `fixed left-0 top-0 z-30 w-12 sm:w-14 ${fine ? "pointer-events-none" : ""}`,
		style: {
			x: sx,
			y: sy
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
			className: "block w-full",
			animate: fine ? {} : { y: [
				0,
				-8,
				0
			] },
			transition: {
				duration: 3,
				repeat: Infinity
			},
			onClick: () => {
				setSleep(false);
				setMsg(content.catLines[Math.floor(Math.random() * content.catLines.length)]);
				setTimeout(() => setMsg(null), 3e3);
			},
			"aria-label": "cat companion",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cat, { variant: sleep ? "sleep" : "sit" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: {
				opacity: 0,
				y: 6,
				scale: .8
			},
			animate: {
				opacity: 1,
				y: 0,
				scale: 1
			},
			exit: { opacity: 0 },
			className: `absolute bottom-full mb-2 w-max max-w-[11rem] rounded-xl bg-cream px-3 py-1.5 font-hand text-base leading-tight text-night shadow-soft ${fine ? "right-0" : "left-0"}`,
			children: msg
		}) })]
	});
}
//#endregion
export { Universe as component };
